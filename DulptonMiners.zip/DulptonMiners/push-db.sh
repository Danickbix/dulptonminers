#!/bin/bash

# Create a file with 'yes' answers for all possible prompts
yes | npm run db:push
